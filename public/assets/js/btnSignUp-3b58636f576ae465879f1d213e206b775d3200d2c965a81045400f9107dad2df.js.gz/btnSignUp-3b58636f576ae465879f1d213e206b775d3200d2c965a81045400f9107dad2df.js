 $("#submit").click(function(event){
		 event.preventDefault();

	 /*$('form').fadeOut(500);*/
	 $('.content').addClass('form-success');
});
